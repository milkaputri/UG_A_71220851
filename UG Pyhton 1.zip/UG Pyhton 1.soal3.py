#3.A. test case 1
import math
p = int(input("Masukan panjang:"))
l = int(input("Masukan lebar:"))
r = int(input("Masukan jari-jari"))
luaslingkaran = float(((math.pi)*(r**2))/2)
luaspp = float(p*l)
jumlahkaleng = float(((luaslingkaran+luaspp)/15))
print ("Area tersebut membutuhkan",math.ceil(jumlahkaleng),"kaleng cat")

#3.B. test case 2
import math
p = int(input("Masukan panjang:"))
l = int(input("Masukan lebar:"))
r = int(input("Masukan jari-jari"))
luaslingkaran = float(((math.pi)*(r**2))/2)
luaspp = float(p*l)
jumlahkaleng = float(((luaslingkaran+luaspp)/15))
print ("Area tersebut membutuhkan",math.ceil(jumlahkaleng),"kaleng cat")

