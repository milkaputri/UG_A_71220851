#1.A. test case 1:
namaanda = str(input("Masukan Nama Anda"))
matkul = str(input("Masukan nama mata kuliah"))
grup = str(input("Masukan grup Anda"))
print ("Haloo!",namaanda*2)
print ("Anda tergabung dalam kelas", matkul, "pada grup",grup)

#1.B. test case 2
namaanda = str(input("Masukan Nama Anda"))
matkul = str(input("Masukan nama mata kuliah"))
grup = str(input("Masukan grup Anda"))
print ("Haloo!",namaanda*2)
print ("Anda tergabung dalam kelas", matkul, "pada grup",grup)
