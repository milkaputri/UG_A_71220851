#2.A. test case 1
suhuF = int(input("Suhu dalam skala Fahrenheit :"))
FkeC = int((5/9)*(suhuF-32))
print (suhuF,"derajat Farenheit dikonversi menjadi", FkeC, "derajat Celcius")
            

#2.B. test case 2
suhuF = int(input("Suhu dalam skala Fahrenheit :"))
FkeC = int((5/9)*(suhuF-32))
print (suhuF,"derajat Farenheit dikonversi menjadi", FkeC, "derajat Celcius")
